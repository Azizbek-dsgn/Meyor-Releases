# Meyor native module launcher
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import importlib
if __name__ == "__main__":
    importlib.import_module('subtitles.model_assets')._meyor_entry()
