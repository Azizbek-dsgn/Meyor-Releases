# Meyor native module launcher
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[0]))
import importlib
if __name__ == "__main__":
    importlib.import_module('install_online')._meyor_entry()
