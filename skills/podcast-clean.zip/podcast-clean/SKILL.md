---
name: podcast-clean
description: Podcast va suhbat montaji — pauza, takror va xatoliklarni kesish, gap tartibi, ikki-uch kamera almashinuvi, ovoz tozaligi. Swible “podcastni tozala”, “avto montaj” so‘ralganda ishlatadi.
---
# Podcast tozalash

## Tartib
1. `swible_analyze_timeline` (Premiere) yoki `lab_analyze` (Lab).
2. Natijani o‘qing: takrorlar, uzun pauzalar, “eee”.
3. Kesish ro‘yxatini o‘zingiz tuzing (`swible_cut_timeline` / `lab_set_cuts`).

## Nima kesiladi
- 0.7 s dan uzun pauza (0.18 s nafas qoladi).
- Qayta boshlangan gapning birinchi urinishi — oxirgi to‘liq urinish qoladi.
- “Kechirasiz, qaytadan aytaman”, texnik gaplar, kamerani sozlash.
- Mavzudan chetga chiqqan, keyin hech qayerda kerak bo‘lmaydigan bo‘lak.

## Nima kesilmaydi
- Kulgi, his-hayajon, savolga o‘ylab javob berish (qisqartiring, o‘chirmang).
- Gap o‘rtasi — hech qachon so‘z ichidan kesilmaydi.

## Kamera
- Gapirayotgan odam ko‘rinadi; javob boshlanganda 0.2–0.4 s kechikib almashing.
- Har 6–9 s da almashinuv yetarli; reaksiya kadri faqat kuchli joyda.
- Bir kameraning o‘zida jump-cut’ni 100↔120 % scale bilan yashiring.

## Ovoz
- Gap −16…−14 LUFS, cho‘qqi −1.5 dB.
- Musiqa gap paytida −18 dB pastga tushadi.

## Hisobot
Natijada: nechchi soniya kesildi, qaysi joylar (vaqt bilan) va odam ko‘rishi kerak bo‘lgan shubhali kesimlar.
