---
name: reels-hook
description: Reels / Shorts / TikTok montaji — birinchi 2 soniyada ushlab qoladigan hook, 9:16 kadr, tez ritm va subtitr qoidalari. Swible “reels qil”, “avto montaj” so‘ralganda ishlatadi.
---
# Reels: kuchli hook

## Qachon
Uzun videodan qisqa vertikal klip (15–60 s) yasalganda: Swible Lab `lab_export reels`, Premiere’da `swible_cut_timeline` + `swible_motion vertical`.

## Lahzani tanlash
1. Transkriptni o‘qing (`swible_get_subtitles` / `lab_get_subtitles`).
2. O‘zi tushunarli bo‘lgan joyni oling: boshlanishi va oxiri butun gap; oldingi kontekstsiz tushuniladi.
3. Kuchli boshlanish turlari (birinchi 2 s): savol, kutilmagan natija yoki raqam, bahsli fikr, “xato qilmang” ogohlantirishi.
4. Uzunlik: 20–45 s eng yaxshi; 60 s dan oshirmang.
5. Bir videodan 1–3 ta reel. Har biri boshqa fikr bo‘lsin.

## Montaj
- Pauza > 0.35 s — kesiladi, nafas uchun 0.1 s qoldiriladi.
- “eee, mmm”, takror boshlangan gaplar kesiladi.
- Har 2–4 s da ko‘rinish o‘zgaradi: zoom (100→112 %), kesim yoki matn chiqishi.
- Yuz kadr markazida, ko‘zlar yuqori uchdan birida (9:16 markaziy kesim).

## Subtitr
- 2–4 so‘zdan, katta, qalin shrift; muhim so‘z rangli (brend `accent`).
- Pastki xavfsiz zonadan yuqorida (y ≈ 70–78 %).
- Hook so‘zi birinchi kadrdan ko‘rinadi.

## Tekshirish
- Birinchi kadr ovozsiz ko‘rilganda ham tushunarli.
- Oxirgi gap tugagan; to‘satdan uzilmagan.
- Ovoz: `clean_audio` yoqilgan, −14 LUFS.
